module.exports.addToGlobal = (name, val) => {
	global[name] = val;
};
