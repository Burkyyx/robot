module.exports = class Emoji {

};
