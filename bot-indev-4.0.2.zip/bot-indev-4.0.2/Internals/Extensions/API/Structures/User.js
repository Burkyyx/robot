/**
 * Represents an extension user
 */
class User {

}

module.exports = User;
