/**
 * Represents a Discord Guild
 */
module.exports = class Guild {

};
