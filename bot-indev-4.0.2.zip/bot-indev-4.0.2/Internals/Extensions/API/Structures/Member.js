class Member {

}

module.exports = Member;
