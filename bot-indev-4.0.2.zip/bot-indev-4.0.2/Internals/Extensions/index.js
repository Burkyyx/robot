module.exports = require("./ExtensionManager");
