module.exports = {
	poll: require("./poll.js"),
	giveaway: require("./giveaway.js"),
	say: require("./say.js"),
};
