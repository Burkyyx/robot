module.exports = {
	extends: "../.eslintrc.js",
	rules: {
		"max-len": "off",
		"no-unused-vars": "off"
	},
};
