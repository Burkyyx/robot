module.exports = {
	discord: {
		clientID: "",
		clientSecret: "",
		clientToken: "",
	},
	tokens: {
		discordBotsOrg: "",
		discordList: "",
		discordBots: "",
		giphyAPI: "",
		googleCSEID: "",
		googleAPI: "",
		imgurClientID: "",
		microsoftTranslation: "",
		twitchClientID: "",
		wolframAppID: "",
		openExchangeRatesKey: "",
		omdbAPI: "",
		gistKey: "",
		openWeatherMap: "",
	},
};
